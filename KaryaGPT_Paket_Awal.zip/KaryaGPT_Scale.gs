/**
 * KaryaGPT — penyimpanan berbentuk tabel + impor massal.
 * Kompatibel dengan kontrak HTML lama: GET action=load -> {ok,state};
 * POST {action:'save', state}. Tidak menghapus KaryaGPT_Data saat setup.
 *
 * Sheet:
 * - KaryaGPT_Data: arsip state lama untuk migrasi/backup; tidak dihapus.
 * - KaryaGPT_Proyek: satu baris per proyek.
 * - KaryaGPT_Latihan: satu baris per pasangan soal-jawaban.
 * - KaryaGPT_Riwayat: satu baris per item riwayat (JSON pada kolom D).
 * - Isian Manual: impor massal, nama proyek di D2, pasangan Q/A D3/D4 dst.
 *
 * Catatan: endpoint kompatibilitas load/save masih mentransfer seluruh state agar
 * HTML lama tetap bekerja. Untuk skala sangat besar, langkah lanjutan adalah API
 * per-proyek/paginasi dan HTML yang memuat proyek aktif saja.
 */
const KG = {
  legacy: 'KaryaGPT_Data', manual: 'Isian Manual', projects: 'KaryaGPT_Proyek',
  examples: 'KaryaGPT_Latihan', history: 'KaryaGPT_Riwayat', stateKey: 'KARYAGPT_STATE',
  firstProjectCol: 4, projectNameRow: 2, firstQARow: 3
};

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  ensureSheet_(ss, KG.legacy, ['key','json_state','updated_at']); // never clear legacy data
  ensureSheet_(ss, KG.projects, ['project_id','project_name','created_at','updated_at']);
  ensureSheet_(ss, KG.examples, ['project_id','example_id','question','answer','source','note','added_at','fingerprint']);
  ensureSheet_(ss, KG.history, ['project_id','history_id','created_at','json_record']);
  const manual = ensureSheet_(ss, KG.manual, []);
  prepareManualSheet_(manual);
  // If normalized tables are empty, safely migrate old state once.
  if (dataRows_(ss.getSheetByName(KG.projects)) === 0 && dataRows_(ss.getSheetByName(KG.examples)) === 0) {
    const old = readLegacyState_(ss.getSheetByName(KG.legacy));
    if (old && Array.isArray(old.projects) && old.projects.length) writeNormalizedState_(old);
  }
  return 'Setup selesai. Data lama tidak dihapus. Isi Isian Manual lalu jalankan importManualData().';
}

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'load';
  try {
    if (action === 'load') return output_({ok:true,state:readState_()}, e);
    if (action === 'health') return output_({ok:true,storage:'normalized-sheets',version:2}, e);
    return output_({ok:false,error:'Aksi GET tidak dikenal.'}, e);
  } catch (err) { return output_({ok:false,error:String(err && err.message || err)}, e); }
}

function doPost(e) {
  try {
    const raw = e && e.postData && e.postData.contents;
    if (!raw) throw new Error('Payload kosong.');
    const payload = JSON.parse(raw);
    if (payload.action !== 'save' || !payload.state || !Array.isArray(payload.state.projects)) {
      throw new Error('Format payload tidak valid.');
    }
    writeNormalizedState_(payload.state);
    return output_({ok:true,savedAt:new Date().toISOString(),storage:'normalized-sheets'}, e);
  } catch (err) { return output_({ok:false,error:String(err && err.message || err)}, e); }
}

function readState_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const psh = ss.getSheetByName(KG.projects), esh = ss.getSheetByName(KG.examples), hsh = ss.getSheetByName(KG.history);
  if (!psh || !esh || !hsh) {
    const old = readLegacyState_(ss.getSheetByName(KG.legacy));
    return old || {projects:[],activeId:''};
  }
  const pRows = rows_(psh), eRows = rows_(esh), hRows = rows_(hsh);
  // On a fresh/older deployment, migrate legacy state if normalized tables are empty.
  if (!pRows.length && !eRows.length) {
    const old = readLegacyState_(ss.getSheetByName(KG.legacy));
    if (old && Array.isArray(old.projects) && old.projects.length) {
      writeNormalizedState_(old);
      return old;
    }
  }
  const projects = new Map();
  pRows.forEach(r => projects.set(String(r[0]), {id:String(r[0]),name:String(r[1]||''),examples:[],history:[]}));
  eRows.forEach(r => {
    const p = projects.get(String(r[0])); if (!p) return;
    p.examples.push({q:String(r[2]??''),a:String(r[3]??''),source:String(r[4]||''),note:String(r[5]||''),addedAt:String(r[6]||'')});
  });
  hRows.forEach(r => {
    const p = projects.get(String(r[0])); if (!p) return;
    try { p.history.push(JSON.parse(String(r[3]||'{}'))); } catch (_) {}
  });
  let activeId = '';
  const savedActive = PropertiesService.getScriptProperties().getProperty('KARYAGPT_ACTIVE_ID') || '';
  const legacy = readLegacyState_(ss.getSheetByName(KG.legacy));
  if (savedActive && projects.has(savedActive)) activeId = savedActive;
  if (!activeId && legacy && legacy.activeId && projects.has(String(legacy.activeId))) activeId = String(legacy.activeId);
  if (!activeId && projects.size) activeId = projects.keys().next().value;
  return {projects:Array.from(projects.values()),activeId};
}

function writeNormalizedState_(state) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const psh = ensureSheet_(ss, KG.projects, ['project_id','project_name','created_at','updated_at']);
  const esh = ensureSheet_(ss, KG.examples, ['project_id','example_id','question','answer','source','note','added_at','fingerprint']);
  const hsh = ensureSheet_(ss, KG.history, ['project_id','history_id','created_at','json_record']);
  const now = new Date();
  const pRows = [], eRows = [], hRows = [];
  (state.projects || []).forEach((p, pi) => {
    if (!p || !p.id) p.id = 'p_migrated_' + Utilities.getUuid();
    pRows.push([String(p.id),String(p.name||'Proyek'),now,now]);
    (Array.isArray(p.examples) ? p.examples : []).forEach((ex, i) => {
      const q = String(ex && ex.q != null ? ex.q : ''), a = String(ex && ex.a != null ? ex.a : '');
      eRows.push([String(p.id),'ex_'+Utilities.getUuid(),q,a,String(ex.source||''),String(ex.note||''),String(ex.addedAt||now.toISOString()),fingerprint_(q,a)]);
    });
    (Array.isArray(p.history) ? p.history : []).forEach((rec, i) => {
      hRows.push([String(p.id),'hist_'+Utilities.getUuid(),String(rec.savedAt||rec.createdAt||now.toISOString()),JSON.stringify(rec)]);
    });
  });
  // Replace only normalized tables. Legacy KaryaGPT_Data is retained as a rollback copy.
  replaceBody_(psh, pRows);
  replaceBody_(esh, eRows);
  replaceBody_(hsh, hRows);
  // Keep active project selection separately; retain the old legacy JSON for rollback.
  PropertiesService.getScriptProperties().setProperty('KARYAGPT_ACTIVE_ID', String(state.activeId || ''));
  // Preserve/update a compact legacy metadata record, not the full state.
  const legacy = ensureSheet_(ss, KG.legacy, ['key','json_state','updated_at']);
  if (legacy.getRange(1,1).getValue() === '') legacy.getRange(1,1,1,3).setValues([['key','json_state','updated_at']]);
  legacy.getRange(2,1).setValue(KG.stateKey + '_NORMALIZED');
  legacy.getRange(2,3).setValue(now);
  SpreadsheetApp.flush();
}

function importManualData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet(), sh = ss.getSheetByName(KG.manual);
  if (!sh) throw new Error('Sheet Isian Manual belum ada. Jalankan setup() dahulu.');
  // Ensure normalized schema and migrate legacy data before importing.
  setupIfNeeded_();
  const psh = ss.getSheetByName(KG.projects), esh = ss.getSheetByName(KG.examples);
  const lastCol = sh.getLastColumn(), lastRow = sh.getLastRow();
  if (lastCol < KG.firstProjectCol || lastRow < KG.projectNameRow) throw new Error('Isi nama proyek di D2 dan seterusnya.');
  const values = sh.getRange(1, KG.firstProjectCol, lastRow, lastCol-KG.firstProjectCol+1).getDisplayValues();
  const existingProjects = new Map(rows_(psh).map(r => [String(r[1]||'').trim().toLowerCase(), String(r[0])]));
  const existingPairs = new Map();
  rows_(esh).forEach(r => { const pid=String(r[0]); if(!existingPairs.has(pid)) existingPairs.set(pid,new Set()); existingPairs.get(pid).add(String(r[7]||fingerprint_(r[2],r[3]))); });
  const newProjects = [], newExamples = [], now = new Date().toISOString();
  let skippedRows=0, importedProjects=0, addedExamples=0;
  for (let c=0;c<values[0].length;c++) {
    const name=String((values[KG.projectNameRow-1]||[])[c]||'').trim();
    if(!name || name.toLowerCase()==='contoh nama proyek') continue;
    let pid=existingProjects.get(name.toLowerCase());
    if(!pid){pid='p_manual_'+Utilities.getUuid().replace(/-/g,'').slice(0,16);existingProjects.set(name.toLowerCase(),pid);newProjects.push([pid,name,now,now]);importedProjects++;}
    if(!existingPairs.has(pid)) existingPairs.set(pid,new Set());
    const seen=existingPairs.get(pid);
    for(let r=KG.firstQARow-1;r<values.length;r+=2){
      const q=String((values[r]||[])[c]||'').trim(), a=String((values[r+1]||[])[c]||'').trim();
      if(!q&&!a) continue;
      if(!q||!a){skippedRows++;continue;}
      const fp=fingerprint_(q,a); if(seen.has(fp)) continue;
      newExamples.push([pid,'ex_'+Utilities.getUuid(),q,a,'manual-sheet','',now,fp]);seen.add(fp);addedExamples++;
    }
  }
  appendRows_(psh,newProjects); appendRows_(esh,newExamples);
  sh.getRange('B1').setValue(new Date()).setNumberFormat('dd mmm yyyy HH:mm:ss');
  SpreadsheetApp.flush();
  const message='Impor selesai. Proyek baru: '+importedProjects+'; pasangan latihan baru: '+addedExamples+(skippedRows?'; pasangan tidak lengkap dilewati: '+skippedRows:'')+'.';
  Logger.log(message);
  return {ok:true,message,importedProjects,addedExamples,skippedRows};
}

function setupIfNeeded_(){
  const ss=SpreadsheetApp.getActiveSpreadsheet();
  ensureSheet_(ss,KG.legacy,['key','json_state','updated_at']);
  ensureSheet_(ss,KG.projects,['project_id','project_name','created_at','updated_at']);
  ensureSheet_(ss,KG.examples,['project_id','example_id','question','answer','source','note','added_at','fingerprint']);
  ensureSheet_(ss,KG.history,['project_id','history_id','created_at','json_record']);
  const psh=ss.getSheetByName(KG.projects),esh=ss.getSheetByName(KG.examples);
  if(dataRows_(psh)===0&&dataRows_(esh)===0){const old=readLegacyState_(ss.getSheetByName(KG.legacy));if(old&&old.projects&&old.projects.length)writeNormalizedState_(old);}
}
function prepareManualSheet_(sh){
  if(sh.getLastRow()===0){
    sh.getRange('A1').setValue('Petunjuk: nama proyek di baris 2 mulai kolom D; mulai baris 3, isi soal dan jawaban secara bergantian.');
    sh.getRange('B1').setValue('Updated'); sh.getRange('C1').setValue('Opsional');
    sh.getRange('D2').setValue('Contoh Nama Proyek'); sh.getRange('D3').setValue('2345'); sh.getRange('D4').setValue('14');
    sh.setFrozenRows(2); sh.setColumnWidth(1,430); sh.setColumnWidth(2,160); sh.setColumnWidth(3,190);
  } else { if(!sh.getRange('B1').getValue()) sh.getRange('B1').setValue('Updated'); }
}
function readLegacyState_(sh){
  if(!sh||sh.getLastRow()<2) return {projects:[],activeId:''};
  // Old format stores the complete JSON in B2; chunked prototype used B2:B<n>.
  const last=Math.max(2,sh.getLastRow());
  const vals=sh.getRange(2,2,last-1,1).getDisplayValues().map(r=>String(r[0]||''));
  let joined=''; for(const v of vals){if(!v) break;joined+=v; if(joined.trim().startsWith('{')){try{return JSON.parse(joined)}catch(_){}}}
  const first=String(sh.getRange(2,2).getValue()||''); try{return JSON.parse(first)}catch(_){}
  return {projects:[],activeId:''};
}
function ensureSheet_(ss,name,headers){let sh=ss.getSheetByName(name);if(!sh)sh=ss.insertSheet(name);if(headers.length&&sh.getLastRow()===0)sh.getRange(1,1,1,headers.length).setValues([headers]);return sh;}
function rows_(sh){if(!sh||sh.getLastRow()<2)return [];return sh.getRange(2,1,sh.getLastRow()-1,sh.getLastColumn()).getValues();}
function dataRows_(sh){return sh&&sh.getLastRow()>1?sh.getLastRow()-1:0;}
function replaceBody_(sh,rows){const old=sh.getLastRow();if(old>1)sh.getRange(2,1,old-1,sh.getLastColumn()).clearContent();if(rows.length){const width=rows[0].length;for(let i=0;i<rows.length;i+=500){const batch=rows.slice(i,i+500);sh.getRange(2+i,1,batch.length,width).setValues(batch);}}}
function appendRows_(sh,rows){if(!rows.length)return;const width=rows[0].length;for(let i=0;i<rows.length;i+=500){const batch=rows.slice(i,i+500);sh.getRange(sh.getLastRow()+1,1,batch.length,width).setValues(batch);}}
function fingerprint_(q,a){const bytes=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(q).trim()+'\u001f'+String(a).trim());return bytes.map(b=>(b+256).toString(16).slice(-2)).join('');}
function output_(obj,e){const callback=e&&e.parameter&&e.parameter.callback,json=JSON.stringify(obj);if(callback&&/^[A-Za-z_$][0-9A-Za-z_$]*$/.test(callback))return ContentService.createTextOutput(callback+'('+json+');').setMimeType(ContentService.MimeType.JAVASCRIPT);return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);}
