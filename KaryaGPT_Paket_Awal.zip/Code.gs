/**
 * KaryaGPT — Google Apps Script connector
 * Buat Google Sheet, buka Extensions > Apps Script, tempel kode ini.
 * Jalankan setup() sekali. Kemudian Deploy > New deployment > Web app.
 * Catatan keamanan: akses "Anyone" tidak menyediakan autentikasi pengguna.
 * Jangan simpan data sensitif pada endpoint publik. Untuk data pribadi,
 * gunakan autentikasi server-side sebelum memakai lintas perangkat.
 */
const SHEET_NAME = 'KaryaGPT_Data';
const STATE_KEY = 'KARYAGPT_STATE';

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) sh = ss.insertSheet(SHEET_NAME);
  sh.clear();
  sh.getRange(1, 1, 1, 3).setValues([['key', 'json_state', 'updated_at']]);
  sh.setFrozenRows(1);
  sh.getRange(2, 1, 1, 3).setValues([[STATE_KEY, JSON.stringify({projects: [], activeId: ''}), new Date()]]);
  return 'Setup selesai.';
}

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'load';
  if (action !== 'load') return output_({ok:false,error:'Aksi GET tidak dikenal.'}, e);
  try {
    return output_({ok:true,state:readState_()}, e);
  } catch (err) {
    return output_({ok:false,error:String(err)}, e);
  }
}

function doPost(e) {
  try {
    const raw = e && e.postData && e.postData.contents;
    if (!raw) return output_({ok:false,error:'Payload kosong.'}, e);
    const payload = JSON.parse(raw);
    if (payload.action !== 'save' || !payload.state || !Array.isArray(payload.state.projects)) {
      return output_({ok:false,error:'Format payload tidak valid.'}, e);
    }
    if (JSON.stringify(payload.state).length > 45000) {
      return output_({ok:false,error:'Data terlalu besar untuk satu sel.'}, e);
    }
    writeState_(payload.state);
    return output_({ok:true,savedAt:new Date().toISOString()}, e);
  } catch (err) {
    return output_({ok:false,error:String(err)}, e);
  }
}

function readState_() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sh) throw new Error('Sheet KaryaGPT_Data belum ada. Jalankan setup().');
  const value = sh.getRange(2, 2).getValue();
  return value ? JSON.parse(value) : {projects:[],activeId:''};
}

function writeState_(state) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.getRange(1, 1, 1, 3).setValues([['key','json_state','updated_at']]);
  }
  sh.getRange(2, 1, 1, 3).setValues([[STATE_KEY, JSON.stringify(state), new Date()]]);
  SpreadsheetApp.flush();
}

function output_(obj, e) {
  const callback = e && e.parameter && e.parameter.callback;
  const json = JSON.stringify(obj);
  if (callback && /^[A-Za-z_$][0-9A-Za-z_$]*$/.test(callback)) {
    return ContentService.createTextOutput(callback + '(' + json + ');')
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}
