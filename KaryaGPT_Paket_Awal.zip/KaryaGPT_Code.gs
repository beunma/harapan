/**
 * KaryaGPT — Google Apps Script connector + import data massal.
 *
 * Sheet KaryaGPT_Data menyimpan state JSON yang dipakai HTML.
 * Sheet Isian Manual menjadi tempat memasukkan data pembelajaran massal.
 *
 * FORMAT Isian Manual:
 *   B1: Updated (diisi otomatis oleh script)
 *   D2, E2, F2, ...: nama proyek
 *   D3: soal 1, D4: jawaban 1, D5: soal 2, D6: jawaban 2, dst.
 *   Setiap kolom proyek menggunakan pasangan soal/jawaban mulai baris 3.
 *
 * Jalankan setup() sekali. Untuk mengimpor data, jalankan importManualData()
 * dari Apps Script. Import menggabungkan data dan menghindari pasangan q/a
 * duplikat; proyek yang sudah ada tidak dihapus.
 */
const SHEET_NAME = 'KaryaGPT_Data';
const MANUAL_SHEET_NAME = 'Isian Manual';
const STATE_KEY = 'KARYAGPT_STATE';
const FIRST_PROJECT_COL = 4; // D
const PROJECT_NAME_ROW = 2;
const FIRST_QA_ROW = 3;

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();

  // Jangan pernah clear() KaryaGPT_Data: itu bisa menghapus data lama.
  let dataSheet = ss.getSheetByName(SHEET_NAME);
  if (!dataSheet) dataSheet = ss.insertSheet(SHEET_NAME);
  if (dataSheet.getLastRow() === 0) {
    dataSheet.getRange(1, 1, 1, 3).setValues([['key', 'json_state', 'updated_at']]);
  } else if (dataSheet.getRange(1, 1).getValue() === '') {
    dataSheet.getRange(1, 1, 1, 3).setValues([['key', 'json_state', 'updated_at']]);
  }
  if (!dataSheet.getRange(2, 2).getValue()) {
    dataSheet.getRange(2, 1, 1, 3).setValues([
      [STATE_KEY, JSON.stringify({projects: [], activeId: ''}), new Date()]
    ]);
  }

  let manual = ss.getSheetByName(MANUAL_SHEET_NAME);
  if (!manual) manual = ss.insertSheet(MANUAL_SHEET_NAME);
  prepareManualSheet_(manual);
  return 'Setup selesai. Isi sheet Isian Manual, lalu jalankan importManualData().';
}

function prepareManualSheet_(sh) {
  // Hanya membuat petunjuk jika sheet masih kosong; tidak menghapus isian pengguna.
  if (sh.getLastRow() === 0) {
    sh.getRange('A1').setValue('Petunjuk: isi nama proyek di baris 2 mulai kolom D. Mulai baris 3, isi soal lalu jawaban secara bergantian.');
    sh.getRange('B1').setValue('Updated');
    sh.getRange('C1').setValue('Kolom C boleh dikosongkan');
    sh.getRange('D2').setValue('Contoh Nama Proyek');
    sh.getRange('D3').setValue('2345');
    sh.getRange('D4').setValue('14');
    sh.getRange('D5').setValue('5678');
    sh.getRange('D6').setValue('26');
    sh.setFrozenRows(2);
    sh.setColumnWidth(1, 430);
    sh.setColumnWidth(2, 160);
    sh.setColumnWidth(3, 190);
    sh.setColumnWidths(4, Math.max(1, sh.getMaxColumns() - 3), 220);
  } else {
    if (sh.getRange('B1').getValue() === '') sh.getRange('B1').setValue('Updated');
    if (sh.getRange('A1').getValue() === '') {
      sh.getRange('A1').setValue('Isi nama proyek di baris 2 mulai kolom D; mulai baris 3 isi soal dan jawaban bergantian.');
    }
  }
}

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'load';
  if (action !== 'load') return output_({ok:false,error:'Aksi GET tidak dikenal.'}, e);
  try {
    return output_({ok:true,state:readState_()}, e);
  } catch (err) {
    return output_({ok:false,error:String(err)}, e);
  }
}

function doPost(e) {
  try {
    const raw = e && e.postData && e.postData.contents;
    if (!raw) return output_({ok:false,error:'Payload kosong.'}, e);
    const payload = JSON.parse(raw);
    if (payload.action !== 'save' || !payload.state || !Array.isArray(payload.state.projects)) {
      return output_({ok:false,error:'Format payload tidak valid.'}, e);
    }
    if (JSON.stringify(payload.state).length > 45000) {
      return output_({ok:false,error:'Data terlalu besar untuk satu sel.'}, e);
    }
    writeState_(payload.state);
    return output_({ok:true,savedAt:new Date().toISOString()}, e);
  } catch (err) {
    return output_({ok:false,error:String(err)}, e);
  }
}

function readState_() {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_NAME);
  if (!sh) throw new Error('Sheet KaryaGPT_Data belum ada. Jalankan setup().');
  const value = sh.getRange(2, 2).getValue();
  return value ? JSON.parse(value) : {projects:[],activeId:''};
}

function writeState_(state) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(SHEET_NAME);
  if (!sh) {
    sh = ss.insertSheet(SHEET_NAME);
    sh.getRange(1, 1, 1, 3).setValues([['key','json_state','updated_at']]);
  }
  sh.getRange(2, 1, 1, 3).setValues([[STATE_KEY, JSON.stringify(state), new Date()]]);
  SpreadsheetApp.flush();
}

/**
 * Impor massal dari Isian Manual ke state KaryaGPT.
 * Untuk tiap kolom D, E, F, ...:
 *   baris 2 = nama proyek
 *   baris 3/4 = soal/jawaban, 5/6 = soal/jawaban, dst.
 *
 * Menggabungkan dengan data proyek yang sudah ada, tanpa menghapus latihan lama.
 * Pasangan yang sama (soal + jawaban) tidak ditambahkan dua kali.
 */
function importManualData() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const sh = ss.getSheetByName(MANUAL_SHEET_NAME);
  if (!sh) throw new Error('Sheet Isian Manual belum ada. Jalankan setup() dahulu.');

  const state = readState_();
  if (!Array.isArray(state.projects)) state.projects = [];
  if (!state.projects.length) state.activeId = '';

  const lastCol = sh.getLastColumn();
  if (lastCol < FIRST_PROJECT_COL) {
    throw new Error('Belum ada kolom proyek. Isi nama proyek mulai D2.');
  }
  const lastRow = Math.max(sh.getLastRow(), FIRST_QA_ROW);
  const values = sh.getRange(1, FIRST_PROJECT_COL, lastRow, lastCol - FIRST_PROJECT_COL + 1).getDisplayValues();

  let importedProjects = 0, addedExamples = 0, skippedRows = 0;
  const now = new Date().toISOString();

  for (let c = 0; c < values[0].length; c++) {
    const projectName = String(values[PROJECT_NAME_ROW - 1][c] || '').trim();
    if (!projectName || projectName.toLowerCase() === 'contoh nama proyek') continue;

    let project = state.projects.find(p => String(p.name || '').trim().toLowerCase() === projectName.toLowerCase());
    if (!project) {
      project = {id: manualUid_(), name: projectName, examples: [], history: []};
      state.projects.push(project);
      importedProjects++;
    }
    if (!Array.isArray(project.examples)) project.examples = [];
    if (!Array.isArray(project.history)) project.history = [];

    const seen = new Set(project.examples.map(ex => manualPairKey_(ex.q, ex.a)));
    for (let r = FIRST_QA_ROW - 1; r < values.length; r += 2) {
      const q = String((values[r] || [])[c] || '').trim();
      const a = String(((values[r + 1] || [])[c] || '')).trim();
      if (!q && !a) continue;
      if (!q || !a) {
        skippedRows++;
        continue;
      }
      const key = manualPairKey_(q, a);
      if (seen.has(key)) continue;
      project.examples.push({q:q, a:a, source:'manual-sheet', addedAt:now});
      seen.add(key);
      addedExamples++;
    }
    if (!state.activeId) state.activeId = project.id;
  }

  if (importedProjects === 0 && addedExamples === 0) {
    sh.getRange('B1').setValue('Tidak ada data baru · ' + new Date());
    return {ok:true, message:'Tidak ada data baru untuk diimpor.', importedProjects, addedExamples, skippedRows};
  }

  writeState_(state);
  sh.getRange('B1').setValue(new Date());
  sh.getRange('B1').setNumberFormat('dd mmm yyyy HH:mm:ss');
  SpreadsheetApp.flush();

  const message = 'Impor selesai. Proyek baru: ' + importedProjects +
    '; pasangan latihan baru: ' + addedExamples +
    (skippedRows ? '; baris tidak lengkap dilewati: ' + skippedRows : '') + '.';
  Logger.log(message);
  return {ok:true, message, importedProjects, addedExamples, skippedRows};
}

function manualPairKey_(q, a) {
  return String(q == null ? '' : q).trim() + '\u001f' + String(a == null ? '' : a).trim();
}

function manualUid_() {
  return 'p_manual_' + Utilities.getUuid().replace(/-/g, '').slice(0, 16);
}

function output_(obj, e) {
  const callback = e && e.parameter && e.parameter.callback;
  const json = JSON.stringify(obj);
  if (callback && /^[A-Za-z_$][0-9A-Za-z_$]*$/.test(callback)) {
    return ContentService.createTextOutput(callback + '(' + json + ');')
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json).setMimeType(ContentService.MimeType.JSON);
}
